package soundsystem;

interface CompactDisc {
    void play();
    void playTrack(int trackNr);
}
