package concert;

public interface Performance {
    void perform();
}
