package concert;

//bisowalna
public interface Encoreable {
    void makeBis();
}
