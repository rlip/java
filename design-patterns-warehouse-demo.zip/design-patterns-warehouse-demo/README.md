# Design Patterns Warehouse Demo

## About

Video course companion code.

## How to Use

The repo contains a branch for each video section.

E.g. if you are at  _Section 2_ and plan to watch _Video 3_ then checkout the branch called `2.3`.

By the end of the video your code should reach the state available in branch `2.4`.
